import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/firebase_notifier.dart';
import 'package:timer_snackbar/timer_snackbar.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
{
  final _loginFailedSnackBar = const SnackBar(content: Text('There was an error logging into the app.'));
  final _loginProcessSnackBar = const SnackBar(content: Text('Login In Process...'));
  final _loginSuccessSnackBar = const SnackBar(content: Text('Login Successful!'));
  final _signUpSuccessSnackBar = const SnackBar(content: Text('Register Successful!, You Can Login Now.'));
  final _signUpFailedSnackBar = const SnackBar(content: Text('There was an error with signUp to the app.'));

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    debugPrint("Built Login Screen");
    return Scaffold(

      appBar: AppBar(title: const Text('Login')),
      body: LayoutBuilder(
        builder: (context, constraints) =>
            Column(
                children: [
                  const SizedBox(height: 50),
                  const Align(alignment: Alignment.center, child: Text('Welcome, Have Fun!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),),),
                  const SizedBox(height: 20),
          TextFieldContainer(
            child: TextFormField(

              controller: emailController,
              autofillHints: const [AutofillHints.email],
              onEditingComplete: ()=>TextInput.finishAutofillContext(),
              decoration: const InputDecoration(
                  border: InputBorder.none,
                  icon: Icon(Icons.email,color: Colors.blue,),
                  labelText: 'Email'),

              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter Email';
                }
                return null;
              },

            ),
          ),

                  TextFieldContainer(
                    child: TextFormField(
                      controller: passwordController,
                      obscureText: true,
                      onEditingComplete: ()=>TextInput.finishAutofillContext(),
                      decoration: const InputDecoration(
                          border: InputBorder.none,
                          icon: Icon(Icons.lock,color: Colors.blue,),
                          labelText: 'Password'),

                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter Password';
                        }
                        return null;
                      },

                    ),
                  ),

        SizedBox(
            width: 250, // <-- match_parent
            height: 42.5, // <-- match-parent
            child: context.watch<FirebaseNotifier>().hintForLoginAfterRegister ? ElevatedButton(
                    onPressed: context.watch<FirebaseNotifier>().signInStatus ? null :  () async
                    {
                      ScaffoldMessenger.of(context).showSnackBar(_loginProcessSnackBar);
                      debugPrint("User trying to login...");
                        await context.read<FirebaseNotifier>().signIn(emailController.text.trim(),  passwordController.text.trim());
                        if (!mounted) {
                          return;
                        }
                        if (context.read<FirebaseNotifier>().currentUserEmail != "")
                        {
                          ScaffoldMessenger.of(context).hideCurrentSnackBar();
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).hideCurrentSnackBar();
                          ScaffoldMessenger.of(context).showSnackBar(_loginSuccessSnackBar);
                        }
                        else
                        {
                          ScaffoldMessenger.of(context).hideCurrentSnackBar();
                          ScaffoldMessenger.of(context).showSnackBar(_loginFailedSnackBar);
                        }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      side: const BorderSide(
                        width: 2.0,
                      ),
                    ),
                    child: const Text('Login'),
                  ) : ElevatedButton(
                    onPressed: context.watch<FirebaseNotifier>().signInStatus ? null :  () async
                    {
                      context.read<FirebaseNotifier>().setHintForLoginAfterRegister(false);
                      ScaffoldMessenger.of(context).showSnackBar(_loginProcessSnackBar);
                      debugPrint("User trying to login...");
                      await context.read<FirebaseNotifier>().signIn(emailController.text.trim(),  passwordController.text.trim());
                      if (!mounted) {
                        return;
                      }
                      if (context.read<FirebaseNotifier>().currentUserEmail != "")
                      {
                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                        ScaffoldMessenger.of(context).showSnackBar(_loginSuccessSnackBar);
                      }
                      else
                      {
                        ScaffoldMessenger.of(context).hideCurrentSnackBar();
                        ScaffoldMessenger.of(context).showSnackBar(_loginFailedSnackBar);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      side: const BorderSide(
                        width: 2.0,
                      ),
                    ),
                    child: const Text('Login'),
                  )),
                  const SizedBox(height: 5),
        SizedBox(
            width: 250, // <-- match_parent
            height: 42.5, // <-- match-parent
            child: ElevatedButton(
                    onPressed: () async
                    {
                      debugPrint("User trying to sign up...");
                      String registerEmail = emailController.text.trim();
                      User? signUpResult = await context.read<FirebaseNotifier>().signUp(registerEmail,  passwordController.text.trim());
                      if (!mounted) {
                        return;
                      }
                      if (signUpResult != null)
                      {
                        ScaffoldMessenger.of(context).showSnackBar(_signUpSuccessSnackBar);
                        context.read<FirebaseNotifier>().setHintForLoginAfterRegister(true);
                        await Future.delayed(const Duration(seconds: 4));
                        if (!mounted) {
                          return;
                        }
                        context.read<FirebaseNotifier>().setHintForLoginAfterRegister(false);

                        }
                      else
                      {
                        ScaffoldMessenger.of(context).showSnackBar(_signUpFailedSnackBar);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      side: const BorderSide(
                        width: 2.0,
                      ),
                    ),
                    child: Text('Sign up'),
                  )),
                  const SizedBox(height: 15),

                  Flexible(
                    fit: FlexFit.tight,
                    flex: 1,
                    child: Image.network("https://pbs.twimg.com/media/EtnyqR0XAAEEpt3?format=jpg&name=small"),
                  ),
                ]
            ),
      ),
    );
  }



}


class TextFieldContainer extends StatelessWidget {
  final Widget child;
  const TextFieldContainer({super.key,
    required this.child,
  }) ;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      width: size.width * 0.8,
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(29),
      ),
      child: child,
    );
  }
}
