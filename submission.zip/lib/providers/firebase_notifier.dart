import 'package:english_words/english_words.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hello_me/classes/MyUser.dart';
import '../enums/app_enums.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseNotifier extends ChangeNotifier
{
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  AuthState _authStatus =  AuthState.UnAuthenticated;
  User? _currentUser;
  String _currentUserEmail = "";
  bool _signInStatus = false;
  MyUser? userDetails;
  String? currentUserDocId;
  Set<WordPair> localSaved = <WordPair>{};
  bool hintForLoginAfterRegister = false;

  FirebaseNotifier();

  User? get currentUser => _currentUser;
  bool get signInStatus => _signInStatus;
  AuthState get authStatus =>  _authStatus;
  String get currentUserEmail => _currentUserEmail;

  set authStatus(AuthState state) {
    _authStatus = state;
    notifyListeners();
  }

  set currentUserEmail(String email) {
    _currentUserEmail = email;
    notifyListeners();
  }

  void setHintForLoginAfterRegister(bool newValue)
  {
    hintForLoginAfterRegister = newValue;
    notifyListeners();
  }

  void addOfflineSuggestion(WordPair word)
  {
    localSaved.add(word);
    notifyListeners();
  }


  void removeOfflineSuggestion(WordPair word)
  {
    localSaved.remove(word);
    notifyListeners();
  }

  Future<void> removeSuggestion(WordPair word) async
  {
    localSaved.remove(word);
    List<String> newList = [];
    for (var element in localSaved) {
      newList.add(element.first[0].toUpperCase() + element.first.substring(1,element.first.length)  + element.second[0].toUpperCase() + element.second.substring(1,element.second.length) );
    }
    await _firestore.collection('users').doc(currentUserDocId).update({"Suggestions":newList});
    notifyListeners();
  }

  Future<void> addSuggestion(WordPair word) async
  {
    localSaved.add(word);
    List<String> newList = [];
    for (var element in localSaved) {
      newList.add(element.first[0].toUpperCase() + element.first.substring(1,element.first.length)  + element.second[0].toUpperCase() + element.second.substring(1,element.second.length) );
    }
    await _firestore.collection('users').doc(currentUserDocId).update({"Suggestions":newList});
    notifyListeners();
  }

  WordPair convertToWordPair(String s) {
    String newS = s.toLowerCase();
    int count = 0;
    int index = 0;
    while (count != 2)
    {
      if (s[index] != newS[index])
      {
        count++;
      }
      index++;
    }
    return WordPair(s.substring(0, index - 1), s.substring(index - 1, s.length));
  }

  void beginAuthStateChanges()
  {
    _auth.authStateChanges().listen((firebaseUser) async {
      if (firebaseUser == null) {
        _currentUser = null;
        _authStatus = AuthState.UnAuthenticated;
      }
      else {
        _currentUser = firebaseUser;
        _authStatus = AuthState.Authenticating;
      }
      notifyListeners();
    } );
  }

  Future<DocumentSnapshot> getUser() async {
    var result = await _firestore
        .collection('users')
        .doc(currentUserDocId)
        .get();
    return result;
  }

  Future<bool> signIn(String email, String password) async {
    try {
      _signInStatus = true;
      authStatus = AuthState.Authenticating;
      notifyListeners();
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      currentUserEmail = email;
      _currentUser = _auth.currentUser;
      await _firestore.collection("users").where("Email", isEqualTo: currentUserEmail).get().then(
            (res) => currentUserDocId = res.docs[0].id,
        onError: (e) => debugPrint("Error completing: $e"),
      );
      debugPrint("DocId: $currentUserDocId");
      final ref = _firestore.collection("users").doc(currentUserDocId).withConverter(
        fromFirestore: MyUser.fromFirestore,
        toFirestore: (MyUser currUserF, _) => currUserF.toFirestore(),
      );
      final docSnap = await ref.get();
      final currUserData = docSnap.data();
      int length = 0;
      if (currUserData != null) {
        length = currUserData.userSuggestions!.length;
        if (length > 0) {
          debugPrint("First Word Value: ${currUserData.userSuggestions![0]} ");
        }
        else {
          debugPrint("The user has not have currently any favorites...");
        }
        var updateList = [];
        for (int i = 0; i < length; i++)
          {
            localSaved.add(convertToWordPair(currUserData.userSuggestions![i]));
          }
          for (var element in localSaved) {
            updateList.add(element.first[0].toUpperCase() + element.first.substring(1,element.first.length)  + element.second[0].toUpperCase() + element.second.substring(1,element.second.length) );
          }
        await _firestore.collection('users').doc(currentUserDocId).update({"Suggestions":updateList});
      }

      return true;
    }
    catch (e) {
      debugPrint("Error occurs at sign in!");
      authStatus = AuthState.UnAuthenticated;
      notifyListeners();
      currentUserEmail = "";
      _signInStatus = false;
      return false;
    }
  }

  Future<User?> signUp(String email, String password) async {
    try {
      authStatus = AuthState.Authenticating;
      notifyListeners();
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: email,
          password: password
      );
      User? user = userCredential.user;
      await _firestore.collection('users')
          .add({
        'Email': email,
        'Suggestions': []
      });
      return user;
    }
    catch (e) {
      authStatus = AuthState.UnAuthenticated;
      notifyListeners();
      return null;
    }
  }

  Future<void> signOut() async
  {
    try {
      _currentUser = null;
      currentUserEmail = "";
      notifyListeners();
      await _auth.signOut();
      _signInStatus = false;
    }
    catch (e) {
      notifyListeners();
    }
  }
  // return 0 if the player is logout, and 1 if the player is login.
  int getUserStatus() {
    if (_currentUser == null)
    {
      return 0;
    }
    return 1;
  }

}

